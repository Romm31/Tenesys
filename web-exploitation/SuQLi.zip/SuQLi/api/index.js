const express = require("express");
const path = require("path");

const app = express();
const port = process.env.PORT || 3000;

const FLAG = "tenesys{sql_1nj3ct10n_5ucc355_k33p_g0ing}";

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

const users = [
  { username: "admin", password: "admin" },
  { username: "user", password: "user" },
];

app.post("/login", (req, res) => {
  const { username, password } = req.body;

  // **Cek SQL Injection**
  if (/\'\s*OR\s*'1'='1/i.test(username)) {
    return res.redirect("/success.html?role=hacker");
  }

  // **Cek apakah username dan password cocok**
  const user = users.find((u) => u.username === username && u.password === password);

  if (user) {
    return user.username === "admin"
      ? res.redirect("/admin.html")
      : res.redirect("/user.html");
  }

  return res.redirect("/failed.html");
});

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"), (err) => {
    if (err) {
      res.status(err.status).send(err.message);
    }
  });
});

// Menangani permintaan untuk file HTML
app.get("/success.html", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "success.html"), (err) => {
    if (err) {
      res.status(err.status).send(err.message);
    }
  });
});

app.get("/admin.html", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "admin.html"), (err) => {
    if (err) {
      res.status(err.status).send(err.message);
    }
  });
});

app.get("/user.html", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "user.html"), (err) => {
    if (err) {
      res.status(err.status).send(err.message);
    }
  });
});

app.get("/failed.html", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "failed.html"), (err) => {
    if (err) {
      res.status(err.status).send(err.message);
    }
  });
});

// Ekspos express app sebagai serverless function
module.exports = (req, res) => {
  app(req, res);
};
